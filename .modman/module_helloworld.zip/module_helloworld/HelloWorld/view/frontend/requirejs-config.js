/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            swiper:  'Ecommage_HelloWorld/js/swiper.min',
            // hello:  'Ecommage_HelloWorld/js/hello'
        }
    }
};
